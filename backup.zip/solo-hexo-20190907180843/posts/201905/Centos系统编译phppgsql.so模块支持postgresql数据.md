title: Centos系统编译php pgsql.so模块支持postgresql数据
date: '2019-05-22 16:23:40'
updated: '2019-05-22 16:42:15'
tags: [Centos, php, postgresql, pgsql.so]
permalink: /centos-build-pgsql.so
---
1、获取php版本

  

```

[root@root lnmp]# php -version

PHP 5.6.36 (cli) (built: Aug 8 2018 10:38:23)

Copyright (c) 1997-2016 The PHP Group

Zend Engine v2.6.0, Copyright (c) 1998-2016 Zend Technologies

with Zend Guard Loader v3.3, Copyright (c) 1998-2014, by Zend Technologies

  

```

  

2、解压php 5.6.36源码

  

```

[root@root lnmp]# cd /home/down/lnmp/src

[root@root lnmp]# tar -xf php-5.6.36.tar.bz2

[root@root lnmp] cd php-5.6.36/ext/pgsql

```

  

3、安装postgresql扩展包postgresql-devel

  

```

yum -y install postgresql-devel

```

  

4、获取phpize和 php安装位置

  

```

[root@root php-5.6.36]# whereis phpize

phpize: /usr/bin/phpize

[root@root php-5.6.36]# whereis php

php: /usr/bin/php /usr/local/php

```

  

5、安装编译pgsql.so

  

```

/usr/bin/phpize

./configure -with-php-config=/usr/bin/php-config

make && make install

```

  

6、配置 php.ini 添加 pgsql.so

  

```

vi /usr/local/php/etc/php.ini

extension_dir ="/usr/local/php/lib/php/extensions/no-debug-non-zts-20131226/"

extension=pgsql.so

```

  

7、重启php

  

```

service php-fpm restart

```